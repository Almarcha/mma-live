# 🥊 MMA Live · UFC PWA

App web progresiva (PWA) de eventos UFC instalable en Android.  
Cartelera en tiempo real, rankings y noticias. Con integración AdSense y afiliados.

---

## 📁 Estructura del proyecto

```
mma-live/
├── public/               ← Archivos de la app (esto se despliega)
│   ├── index.html        ← App principal
│   ├── manifest.json     ← Configuración PWA
│   ├── sw.js             ← Service Worker (modo offline)
│   └── events.json       ← Datos generados por el scraper (auto)
│
├── scripts/
│   └── scraper.py        ← Script Python que actualiza eventos
│
└── .github/
    └── workflows/
        └── update-and-deploy.yml  ← Automatización GitHub Actions
```

---

## 🚀 Despliegue en GitHub Pages (gratis)

### Paso 1 — Crear repositorio
1. Ve a https://github.com/new
2. Nombre: `mma-live` (o el que quieras)
3. Público (necesario para GitHub Pages gratis)
4. Crea el repo

### Paso 2 — Subir archivos
```bash
git init
git add .
git commit -m "Primer commit MMA Live"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/mma-live.git
git push -u origin main
```

### Paso 3 — Activar GitHub Pages
1. Ve a tu repo → **Settings** → **Pages**
2. Source: **GitHub Actions**
3. Guarda

### Paso 4 — Ejecutar el workflow
1. Ve a **Actions** → `Update UFC Events & Deploy`
2. Pulsa **Run workflow**
3. En 2-3 minutos tu app estará en:  
   `https://TU_USUARIO.github.io/mma-live/`

---

## 💰 Configurar Google AdSense

1. Crea cuenta en https://adsense.google.com
2. Añade tu dominio (`TU_USUARIO.github.io`)
3. Espera aprobación (1-3 días)
4. Una vez aprobado, busca en `index.html`:
   ```
   ca-pub-XXXXXXXXXXXXXXXXX
   ```
   Sustitúyelo por tu **Publisher ID** (formato: `ca-pub-1234567890123456`)

5. Para los slots de anuncio, busca:
   ```
   data-ad-slot="XXXXXXXXXX"
   ```
   Sustitúyelo por tus **Slot IDs** de AdSense (uno por bloque)

---

## 🎰 Configurar afiliados de apuestas

En `index.html` busca:
```html
onclick="window.open('https://TU-ENLACE-AFILIADO.com','_blank')"
```

Sustitúyelo por tu enlace de afiliado de:
- **Bet365** → https://www.bet365.com/affiliates
- **Betway** → https://www.betwaypartners.com
- **Unibet** → https://affiliates.unibet.com

💡 Los programas CPA pagan 50-150€ por usuario registrado que deposite.

---

## 🔄 Automatización del scraper

El archivo `.github/workflows/update-and-deploy.yml` configura:
- Ejecución automática **2 veces al día** (8:00 y 20:00 UTC)
- Ejecución manual desde GitHub Actions
- **Commit automático** de `events.json` si hay cambios
- **Deploy automático** a GitHub Pages

Para ejecutar manualmente:
```bash
# Instalar dependencias
pip install requests beautifulsoup4 lxml

# Ejecutar scraper
python scripts/scraper.py
```

---

## 📲 Instalar en Android

1. Abre la URL de la app en **Chrome para Android**
2. Pulsa el menú **⋮** (tres puntos)
3. Selecciona **"Añadir a pantalla de inicio"**
4. Confirma → aparecerá como app nativa en tu móvil

---

## 🛠️ Alternativas de despliegue gratuito

| Plataforma | URL ejemplo | Límite gratis |
|---|---|---|
| **GitHub Pages** | `usuario.github.io/mma-live` | Ilimitado para repos públicos |
| **Netlify** | `mma-live.netlify.app` | 100GB/mes |
| **Vercel** | `mma-live.vercel.app` | 100GB/mes |

### Netlify (alternativa más fácil)
1. Ve a https://netlify.com → New site from Git
2. Conecta tu repositorio GitHub
3. Build command: (vacío)
4. Publish directory: `public`
5. Deploy → listo

---

## 📝 Notas legales

- Los datos de la UFC son públicos pero pertenecen a Zuffa LLC
- El scraper respeta los tiempos de espera para no sobrecargar servidores
- Para uso comercial intensivo considera usar una API oficial como SportsData.io
- Los anuncios de apuestas requieren aviso legal de juego responsable (+18)

---

## 🔧 Personalización

Para cambiar los datos de la cartelera, edita el objeto `APP_DATA` en `index.html`.  
Para añadir nuevos eventos automáticamente, el scraper actualizará `events.json`  
pero la integración completa con la app requiere leer el JSON via fetch().

```javascript
// Para cargar events.json dinámicamente (opcional):
fetch('./events.json')
  .then(r => r.json())
  .then(data => {
    APP_DATA.events = data.events;
    renderEvents();
  });
```
